"""
Authentication package for the expense tracker backend.
"""
